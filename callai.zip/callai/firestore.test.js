const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_1";
const BOB_UID = "bob_uid_2";
const CHARLIE_UID = "charlie_uid_3";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function nowPast() {
  return new Date(Date.now() - 1000);
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write any collection", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("publicProfiles").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("usernames").doc("alice_dev").get());
  await assertFails(
    unauthDb
      .collection("conversations")
      .where("memberUids", "array-contains", ALICE_UID)
      .get()
  );
  await assertFails(
    unauthDb
      .collection("calls")
      .where("participantUids", "array-contains", ALICE_UID)
      .get()
  );
});

test("User registration: PrivateUser, PublicProfile, and UsernameClaim enforce ownership, uniqueness, and PII isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const ts = nowPast();

  // Alice creates her private user, public profile, and username claim
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      uid: ALICE_UID,
      email: "alice@example.com",
      username: "alice_dev",
      displayName: "Alice",
      statusText: "Available",
      createdAt: ts,
      updatedAt: ts,
    })
  );
  await assertSucceeds(
    aliceDb.collection("publicProfiles").doc(ALICE_UID).set({
      uid: ALICE_UID,
      username: "alice_dev",
      displayName: "Alice",
      statusText: "Available",
      online: true,
      createdAt: ts,
      updatedAt: ts,
    })
  );
  await assertSucceeds(
    aliceDb.collection("usernames").doc("alice_dev").set({
      uid: ALICE_UID,
      displayName: "Alice",
      createdAt: ts,
    })
  );

  // Bob CANNOT read Alice's private PII doc or list publicProfiles/usernames
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("publicProfiles").get());
  await assertFails(bobDb.collection("usernames").get());

  // Bob CAN look up exact username and exact public profile (no PII)
  await assertSucceeds(bobDb.collection("usernames").doc("alice_dev").get());
  await assertSucceeds(bobDb.collection("publicProfiles").doc(ALICE_UID).get());

  // Bob CANNOT overwrite Alice's existing username claim
  await assertFails(
    bobDb.collection("usernames").doc("alice_dev").set({
      uid: BOB_UID,
      displayName: "Bob",
      createdAt: ts,
    })
  );

  // Shadow field injection rejected
  await assertFails(
    bobDb.collection("users").doc(BOB_UID).set({
      uid: BOB_UID,
      email: "bob@example.com",
      username: "bob_99",
      displayName: "Bob",
      isAdmin: true,
      createdAt: ts,
      updatedAt: ts,
    })
  );
});

test("Contacts subcollection allows owner CRUD and blocks cross-user access", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const ts = nowPast();

  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("contacts")
      .doc(BOB_UID)
      .set({
        contactUid: BOB_UID,
        username: "bob_99",
        displayName: "Bob",
        nickname: "Best Friend",
        createdAt: ts,
        updatedAt: ts,
      })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("contacts").get()
  );

  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("contacts")
      .doc(BOB_UID)
      .update({
        nickname: "Work Partner",
        updatedAt: nowPast(),
      })
  );

  // Bob cannot read or modify Alice's contacts
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("contacts").get()
  );
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("contacts")
      .doc(BOB_UID)
      .delete()
  );
});

test("Conversations, groups, and messages enforce membership, admin controls, and query alignment", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();
  const ts = nowPast();

  // Alice creates a group with Bob
  await assertSucceeds(
    aliceDb.collection("conversations").doc("grp_study").set({
      type: "group",
      title: "Study Squad",
      description: "AI study group",
      createdBy: ALICE_UID,
      memberUids: [ALICE_UID, BOB_UID],
      adminUids: [ALICE_UID],
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Filtered memberUids queries succeed for Alice & Bob; unfiltered query fails
  await assertSucceeds(
    bobDb
      .collection("conversations")
      .where("memberUids", "array-contains", BOB_UID)
      .get()
  );
  await assertFails(bobDb.collection("conversations").get());

  // Charlie (non-member) cannot read group or send messages
  await assertFails(charlieDb.collection("conversations").doc("grp_study").get());
  await assertFails(
    charlieDb
      .collection("conversations")
      .doc("grp_study")
      .collection("messages")
      .doc("msg_bad")
      .set({
        conversationId: "grp_study",
        senderId: CHARLIE_UID,
        senderName: "Charlie",
        text: "Intruder",
        messageType: "text",
        memberUids: [ALICE_UID, BOB_UID, CHARLIE_UID],
        createdAt: ts,
        updatedAt: ts,
      })
  );

  // Bob (member) sends message & updates lastMessage preview
  await assertSucceeds(
    bobDb
      .collection("conversations")
      .doc("grp_study")
      .collection("messages")
      .doc("msg_1")
      .set({
        conversationId: "grp_study",
        senderId: BOB_UID,
        senderName: "Bob",
        text: "Hey, ready for our call?",
        messageType: "text",
        memberUids: [ALICE_UID, BOB_UID],
        createdAt: ts,
        updatedAt: ts,
      })
  );
  await assertSucceeds(
    bobDb.collection("conversations").doc("grp_study").update({
      lastMessageText: "Hey, ready for our call?",
      lastMessageSenderName: "Bob",
      lastMessageAt: nowPast(),
      updatedAt: nowPast(),
    })
  );

  // Filtered messages query works for Alice; unfiltered fails
  await assertSucceeds(
    aliceDb
      .collection("conversations")
      .doc("grp_study")
      .collection("messages")
      .where("memberUids", "array-contains", ALICE_UID)
      .get()
  );
  await assertFails(
    aliceDb
      .collection("conversations")
      .doc("grp_study")
      .collection("messages")
      .get()
  );

  // Non-admin Bob cannot rename the group; admin Alice can add Charlie
  await assertFails(
    bobDb.collection("conversations").doc("grp_study").update({
      title: "Hacked Group",
      updatedAt: nowPast(),
    })
  );
  await assertSucceeds(
    aliceDb.collection("conversations").doc("grp_study").update({
      memberUids: [ALICE_UID, BOB_UID, CHARLIE_UID],
      updatedAt: nowPast(),
    })
  );
});

test("Calls & CallEvents enforce participant access, AI sharing, and terminal state locking", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();
  const ts = nowPast();

  // Alice starts a video call with Bob
  await assertSucceeds(
    aliceDb.collection("calls").doc("call_100").set({
      callerId: ALICE_UID,
      callerName: "Alice",
      callerUsername: "alice_dev",
      calleeName: "Bob",
      participantUids: [ALICE_UID, BOB_UID],
      callMode: "video",
      status: "ringing",
      aiActive: false,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Bob queries his calls & accepts call
  await assertSucceeds(
    bobDb
      .collection("calls")
      .where("participantUids", "array-contains", BOB_UID)
      .get()
  );
  await assertSucceeds(
    bobDb.collection("calls").doc("call_100").update({
      status: "active",
      updatedAt: nowPast(),
    })
  );

  // Alice activates AI and posts shared AI Q&A event
  await assertSucceeds(
    aliceDb.collection("calls").doc("call_100").update({
      aiActive: true,
      lastAiPrompt: "Solve x^2 - 9 = 0",
      lastAiAnswer: "x = 3 or x = -3",
      lastAiByName: "Alice",
      updatedAt: nowPast(),
    })
  );
  await assertSucceeds(
    aliceDb
      .collection("calls")
      .doc("call_100")
      .collection("events")
      .doc("evt_1")
      .set({
        callId: "call_100",
        senderId: ALICE_UID,
        senderName: "Alice",
        eventType: "ai_answer",
        content: "x = 3 or x = -3",
        participantUids: [ALICE_UID, BOB_UID],
        createdAt: ts,
      })
  );

  // Charlie cannot join or read call
  await assertFails(charlieDb.collection("calls").doc("call_100").get());

  // End call -> terminal state locking prevents further updates
  await assertSucceeds(
    bobDb.collection("calls").doc("call_100").update({
      status: "ended",
      endedAt: nowPast(),
      updatedAt: nowPast(),
    })
  );
  await assertFails(
    aliceDb.collection("calls").doc("call_100").update({
      status: "active",
      updatedAt: nowPast(),
    })
  );
});
