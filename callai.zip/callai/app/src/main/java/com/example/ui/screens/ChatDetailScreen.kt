package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Summarize
import androidx.compose.material.icons.filled.TipsAndUpdates
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.audio.CallAudioEngine
import com.example.data.model.CallMode
import com.example.data.model.ChatMessage
import com.example.data.model.Contact
import com.example.data.model.Conversation
import com.example.data.model.ConversationType
import com.example.data.model.MessageType
import com.example.data.model.PrivateUser
import com.example.data.model.UiState
import com.example.ui.components.AiGlowBadge
import com.example.ui.components.UserAvatar
import com.example.ui.theme.AiBubbleDark
import com.example.ui.theme.AiViolet
import com.example.ui.theme.CallEndRed
import com.example.ui.theme.CyanSpark
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceHigh
import com.example.ui.theme.ReceivedBubbleDark
import com.example.ui.theme.SentBubbleDark
import com.example.viewmodel.AiUiState
import com.example.viewmodel.ChatDetailViewModel
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatDetailScreen(
    conversation: Conversation,
    chatTitle: String,
    myProfile: PrivateUser,
    contacts: List<Contact>,
    viewModel: ChatDetailViewModel,
    onBack: () -> Unit,
    onStartCall: (CallMode) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val audioEngine = remember(context) { CallAudioEngine(context) }
    DisposableEffect(audioEngine) {
        onDispose { audioEngine.release() }
    }

    val messagesState by viewModel.messagesState.collectAsStateWithLifecycle()
    val aiState by viewModel.aiState.collectAsStateWithLifecycle()
    val smartReplies by viewModel.smartReplies.collectAsStateWithLifecycle()
    val isLoadingReplies by viewModel.isLoadingReplies.collectAsStateWithLifecycle()
    val groupMembers by viewModel.members.collectAsStateWithLifecycle()
    val actionError by viewModel.actionError.collectAsStateWithLifecycle()
    val isRecordingVoice by audioEngine.isRecordingVoiceCommand.collectAsStateWithLifecycle()

    var messageText by remember { mutableStateOf("") }
    var showAiSheet by remember { mutableStateOf(false) }
    var showGroupDialog by remember { mutableStateOf(false) }
    var pendingVoiceAi by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(actionError) {
        if (!actionError.isNullOrBlank()) {
            snackbarHostState.showSnackbar(actionError!!)
            viewModel.clearError()
        }
    }

    val audioPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted && pendingVoiceAi) {
            pendingVoiceAi = false
            audioEngine.startMicMonitor(scope)
            audioEngine.startVoiceCommandCapture()
            showAiSheet = true
        }
    }

    fun triggerVoiceCommand() {
        val hasPerm = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO,
        ) == PackageManager.PERMISSION_GRANTED
        if (hasPerm) {
            if (!isRecordingVoice) {
                audioEngine.startMicMonitor(scope)
                audioEngine.startVoiceCommandCapture()
                showAiSheet = true
            } else {
                val wav = audioEngine.stopVoiceCommandCaptureAsWav()
                if (wav != null) {
                    viewModel.askAiWithVoice(wav, chatTitle)
                }
            }
        } else {
            pendingVoiceAi = true
            audioPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    val listState = rememberLazyListState()
    val messages = (messagesState as? UiState.Success)?.data ?: emptyList()
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        containerColor = ObsidianBg,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = ObsidianSurface),
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("chat_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable(enabled = conversation.conversationType == ConversationType.GROUP) {
                            viewModel.loadGroupMembers(conversation.memberUids)
                            showGroupDialog = true
                        },
                    ) {
                        UserAvatar(
                            name = chatTitle,
                            size = 38.dp,
                            isGroup = conversation.conversationType == ConversationType.GROUP,
                        )
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(
                                text = chatTitle,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = if (conversation.conversationType == ConversationType.GROUP) {
                                    "${conversation.memberUids.size} أعضاء • اضغط للإدارة"
                                } else {
                                    "متاح للمكالمات مع AI"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showAiSheet = true },
                        modifier = Modifier.testTag("chat_ai_top_button"),
                    ) {
                        Icon(Icons.Filled.AutoAwesome, contentDescription = "مساعد AI", tint = CyanSpark)
                    }
                    IconButton(
                        onClick = { onStartCall(CallMode.AUDIO) },
                        modifier = Modifier.testTag("chat_audio_call_button"),
                    ) {
                        Icon(Icons.Filled.Call, contentDescription = "مكالمة صوتية", tint = EmeraldGlow)
                    }
                    IconButton(
                        onClick = { onStartCall(CallMode.VIDEO) },
                        modifier = Modifier.testTag("chat_video_call_button"),
                    ) {
                        Icon(Icons.Filled.Videocam, contentDescription = "مكالمة فيديو", tint = CyanSpark)
                    }
                    if (conversation.conversationType == ConversationType.GROUP) {
                        IconButton(
                            onClick = {
                                viewModel.loadGroupMembers(conversation.memberUids)
                                showGroupDialog = true
                            },
                            modifier = Modifier.testTag("group_manage_button"),
                        ) {
                            Icon(Icons.Filled.Group, contentDescription = "إدارة المجموعة")
                        }
                    }
                },
            )
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ObsidianSurface)
                    .navigationBarsPadding()
                    .imePadding(),
            ) {
                // Quick Smart Replies strip when loaded
                AnimatedVisibility(visible = smartReplies.isNotEmpty()) {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(smartReplies) { reply ->
                            AssistChip(
                                onClick = {
                                    viewModel.sendMessage(conversation, myProfile, reply)
                                },
                                label = { Text(reply, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                leadingIcon = {
                                    Icon(
                                        Icons.Filled.AutoAwesome,
                                        contentDescription = null,
                                        tint = CyanSpark,
                                        modifier = Modifier.size(16.dp),
                                    )
                                },
                                colors = AssistChipDefaults.assistChipColors(
                                    containerColor = ObsidianSurfaceHigh,
                                    labelColor = MaterialTheme.colorScheme.onSurface,
                                ),
                            )
                        }
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                ) {
                    // Dedicated AI Assistant button
                    IconButton(
                        onClick = { showAiSheet = true },
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(listOf(CyanSpark.copy(alpha = 0.25f), AiViolet.copy(alpha = 0.3f))),
                            )
                            .testTag("composer_ai_button"),
                    ) {
                        Icon(Icons.Filled.AutoAwesome, contentDescription = "فتح مساعد AI", tint = CyanSpark)
                    }

                    Spacer(Modifier.width(6.dp))

                    // Voice Command AI button
                    IconButton(
                        onClick = { triggerVoiceCommand() },
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(if (isRecordingVoice) CallEndRed else ObsidianSurfaceHigh)
                            .testTag("composer_voice_ai_button"),
                    ) {
                        Icon(
                            imageVector = if (isRecordingVoice) Icons.Filled.Stop else Icons.Filled.Mic,
                            contentDescription = "أمر صوتي للذكاء الاصطناعي",
                            tint = if (isRecordingVoice) Color.White else EmeraldGlow,
                        )
                    }

                    Spacer(Modifier.width(8.dp))

                    OutlinedTextField(
                        value = messageText,
                        onValueChange = { messageText = it.take(4000) },
                        placeholder = { Text("اكتب رسالة...") },
                        maxLines = 4,
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_message_input"),
                    )

                    Spacer(Modifier.width(8.dp))

                    IconButton(
                        onClick = {
                            val toSend = messageText
                            messageText = ""
                            viewModel.sendMessage(conversation, myProfile, toSend)
                        },
                        enabled = messageText.isNotBlank(),
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(if (messageText.isNotBlank()) EmeraldGlow else ObsidianSurfaceHigh)
                            .testTag("send_message_button"),
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "إرسال",
                            tint = if (messageText.isNotBlank()) ObsidianBg else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            when (messagesState) {
                is UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = EmeraldGlow)
                }
                is UiState.Error -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text((messagesState as UiState.Error).message, color = MaterialTheme.colorScheme.error)
                }
                is UiState.Success -> {
                    if (messages.isEmpty()) {
                        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                AiGlowBadge("مساعد AI جاهز داخل المحادثة")
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    text = "أرسل أول رسالة أو اضغط زر AI أو الميكروفون للمساعدة الذكية.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            state = listState,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxSize(),
                        ) {
                            items(messages, key = { it.id }) { msg ->
                                MessageBubble(
                                    message = msg,
                                    isMine = msg.senderId == myProfile.uid,
                                    showSenderName = conversation.conversationType == ConversationType.GROUP,
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAiSheet) {
        ModalBottomSheet(
            onDismissRequest = {
                if (isRecordingVoice) audioEngine.stopVoiceCommandCaptureAsWav()
                showAiSheet = false
            },
            containerColor = ObsidianSurface,
        ) {
            InChatAiAssistantSheetContent(
                chatTitle = chatTitle,
                aiState = aiState,
                smartReplies = smartReplies,
                isLoadingReplies = isLoadingReplies,
                isRecordingVoice = isRecordingVoice,
                onAskText = { prompt -> viewModel.askAi(prompt, chatTitle) },
                onSummarize = { viewModel.summarizeChat(chatTitle) },
                onSuggestReplies = { viewModel.fetchSmartReplies() },
                onToggleVoiceRecord = { triggerVoiceCommand() },
                onUseReply = { reply ->
                    messageText = reply
                    showAiSheet = false
                },
                onShareAiToChat = {
                    viewModel.shareAiAnswerToChat(conversation, myProfile)
                    showAiSheet = false
                },
                onSpeakText = { text -> audioEngine.speakText(text) },
            )
        }
    }

    if (showGroupDialog) {
        GroupManagementDialog(
            conversation = conversation,
            myUid = myProfile.uid,
            members = groupMembers,
            contacts = contacts,
            onDismiss = { showGroupDialog = false },
            onUpdateInfo = { title, desc -> viewModel.updateGroupInfo(title, desc) },
            onAddMember = { uid -> viewModel.addMember(conversation.memberUids, uid) },
            onRemoveMember = { uid ->
                viewModel.removeMember(conversation.memberUids, conversation.adminUids, uid)
            },
        )
    }
}

@Composable
private fun MessageBubble(
    message: ChatMessage,
    isMine: Boolean,
    showSenderName: Boolean,
) {
    val isAi = message.parsedType == MessageType.AI_ANSWER
    val timeText = message.createdAt?.toDate()?.let {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(it)
    } ?: ""

    val bubbleColor = when {
        isAi -> AiBubbleDark
        isMine -> SentBubbleDark
        else -> ReceivedBubbleDark
    }

    Row(
        horizontalArrangement = if (isMine && !isAi) Arrangement.End else Arrangement.Start,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Surface(
            color = bubbleColor,
            shape = RoundedCornerShape(
                topStart = 18.dp,
                topEnd = 18.dp,
                bottomStart = if (isMine && !isAi) 18.dp else 4.dp,
                bottomEnd = if (isMine && !isAi) 4.dp else 18.dp,
            ),
            modifier = Modifier
                .widthIn(max = 310.dp)
                .then(
                    if (isAi) {
                        Modifier.border(
                            1.dp,
                            Brush.horizontalGradient(listOf(CyanSpark, AiViolet)),
                            RoundedCornerShape(18.dp),
                        )
                    } else Modifier,
                ),
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                if (isAi) {
                    AiGlowBadge(label = "إجابة AI من ${message.senderName}")
                    Spacer(Modifier.height(6.dp))
                } else if (showSenderName && !isMine) {
                    Text(
                        text = message.senderName,
                        style = MaterialTheme.typography.labelMedium,
                        color = CyanSpark,
                    )
                    Spacer(Modifier.height(2.dp))
                }
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = timeText,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.End),
                )
            }
        }
    }
}

@Composable
private fun InChatAiAssistantSheetContent(
    chatTitle: String,
    aiState: AiUiState,
    smartReplies: List<String>,
    isLoadingReplies: Boolean,
    isRecordingVoice: Boolean,
    onAskText: (String) -> Unit,
    onSummarize: () -> Unit,
    onSuggestReplies: () -> Unit,
    onToggleVoiceRecord: () -> Unit,
    onUseReply: (String) -> Unit,
    onShareAiToChat: () -> Unit,
    onSpeakText: (String) -> Unit,
) {
    var promptText by remember { mutableStateOf("") }

    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 8.dp)
            .navigationBarsPadding(),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth(),
        ) {
            AiGlowBadge("مساعد CallAI • يفهم سياق: $chatTitle")
            IconButton(
                onClick = onToggleVoiceRecord,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(if (isRecordingVoice) CallEndRed else EmeraldGlow.copy(alpha = 0.18f))
                    .testTag("sheet_voice_command_button"),
            ) {
                Icon(
                    imageVector = if (isRecordingVoice) Icons.Filled.Stop else Icons.Filled.Mic,
                    contentDescription = "أمر صوتي",
                    tint = if (isRecordingVoice) Color.White else EmeraldGlow,
                )
            }
        }

        if (isRecordingVoice) {
            Surface(
                color = CallEndRed.copy(alpha = 0.16f),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.padding(12.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = CallEndRed)
                        Spacer(Modifier.width(8.dp))
                        Text("جاري تسجيل أمرك الصوتي... اضغط إرسال عند الانتهاء")
                    }
                    TextButton(onClick = onToggleVoiceRecord) {
                        Text("إرسال الصوت", color = EmeraldGlow, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Quick Context Actions
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            OutlinedButton(
                onClick = onSummarize,
                modifier = Modifier.weight(1f).testTag("ai_summarize_button"),
            ) {
                Icon(Icons.Filled.Summarize, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("لخّص المحادثة")
            }
            OutlinedButton(
                onClick = onSuggestReplies,
                modifier = Modifier.weight(1f).testTag("ai_suggest_replies_button"),
            ) {
                Icon(Icons.Filled.TipsAndUpdates, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (isLoadingReplies) "جاري الاقتراح..." else "اقترح ردود")
            }
        }

        if (smartReplies.isNotEmpty()) {
            Text("اضغط على رد لنسخه وإرساله:", style = MaterialTheme.typography.labelLarge, color = CyanSpark)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                smartReplies.forEach { reply ->
                    Surface(
                        color = ObsidianSurfaceHigh,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onUseReply(reply) },
                    ) {
                        Text(
                            text = reply,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(12.dp),
                        )
                    }
                }
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth(),
        ) {
            OutlinedTextField(
                value = promptText,
                onValueChange = { promptText = it.take(1000) },
                placeholder = { Text("اسأل AI أي سؤال عن المحادثة أو غيرها...") },
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_sheet_prompt_input"),
            )
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = {
                    val p = promptText
                    promptText = ""
                    onAskText(p)
                },
                enabled = promptText.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = CyanSpark, contentColor = ObsidianBg),
                modifier = Modifier
                    .height(54.dp)
                    .testTag("ai_sheet_send_button"),
            ) {
                Text("اسأل", fontWeight = FontWeight.Bold)
            }
        }

        when (aiState) {
            is AiUiState.Idle -> Unit
            is AiUiState.Loading -> Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = CyanSpark, strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Text("جاري التفكير...", color = CyanSpark)
            }
            is AiUiState.Streaming -> Surface(
                color = ObsidianSurfaceHigh,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(aiState.text, modifier = Modifier.padding(14.dp), style = MaterialTheme.typography.bodyMedium)
            }
            is AiUiState.Success -> Surface(
                color = ObsidianSurfaceHigh,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyanSpark.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(aiState.text, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = onShareAiToChat,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGlow, contentColor = ObsidianBg),
                            modifier = Modifier.weight(1f),
                        ) {
                            Text("إرسال للدردشة", fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(onClick = { onSpeakText(aiState.text) }) {
                            Icon(Icons.Filled.VolumeUp, contentDescription = "قراءة صوتية")
                        }
                    }
                }
            }
            is AiUiState.Error -> Text(aiState.message, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun GroupManagementDialog(
    conversation: Conversation,
    myUid: String,
    members: List<com.example.data.model.PublicProfile>,
    contacts: List<Contact>,
    onDismiss: () -> Unit,
    onUpdateInfo: (title: String, desc: String?) -> Unit,
    onAddMember: (String) -> Unit,
    onRemoveMember: (String) -> Unit,
) {
    val isAdmin = conversation.adminUids.contains(myUid)
    var title by remember(conversation.id) { mutableStateOf(conversation.title) }
    var desc by remember(conversation.id) { mutableStateOf(conversation.description ?: "") }
    val addableContacts = contacts.filter { !conversation.memberUids.contains(it.contactUid) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إدارة المجموعة (${conversation.memberUids.size} أعضاء)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (isAdmin) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it.take(80) },
                        label = { Text("اسم المجموعة") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = desc,
                        onValueChange = { desc = it.take(240) },
                        label = { Text("الوصف") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    Text(conversation.title, style = MaterialTheme.typography.titleMedium)
                    conversation.description?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                }

                Text("الأعضاء الحاليون:", style = MaterialTheme.typography.labelLarge)
                LazyColumn(modifier = Modifier.height(120.dp)) {
                    items(members, key = { it.uid }) { member ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        ) {
                            Text("${member.displayName} (@${member.username})", modifier = Modifier.weight(1f))
                            if (isAdmin && member.uid != myUid) {
                                IconButton(onClick = { onRemoveMember(member.uid) }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "إزالة", tint = CallEndRed)
                                }
                            }
                        }
                    }
                }

                if (isAdmin && addableContacts.isNotEmpty()) {
                    Text("إضافة من جهات الاتصال:", style = MaterialTheme.typography.labelLarge, color = EmeraldGlow)
                    LazyColumn(modifier = Modifier.height(90.dp)) {
                        items(addableContacts, key = { it.contactUid }) { c ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Text("${c.nickname ?: c.displayName} (@${c.username})")
                                IconButton(onClick = { onAddMember(c.contactUid) }) {
                                    Icon(Icons.Filled.Add, contentDescription = "إضافة", tint = EmeraldGlow)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (isAdmin) {
                Button(
                    onClick = {
                        onUpdateInfo(title, desc.ifBlank { null })
                        onDismiss()
                    },
                    enabled = title.isNotBlank(),
                ) { Text("حفظ التعديلات") }
            } else {
                TextButton(onClick = onDismiss) { Text("إغلاق") }
            }
        },
        dismissButton = {
            if (isAdmin) {
                TextButton(onClick = onDismiss) { Text("إلغاء") }
            }
        },
    )
}
