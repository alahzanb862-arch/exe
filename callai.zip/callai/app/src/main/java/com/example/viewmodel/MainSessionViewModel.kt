package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.CallMode
import com.example.data.model.CallSession
import com.example.data.model.CallStatus
import com.example.data.model.Contact
import com.example.data.model.Conversation
import com.example.data.model.ConversationType
import com.example.data.model.PrivateUser
import com.example.data.model.PublicProfile
import com.example.data.model.UiState
import com.example.data.repository.AuthProfileRepository
import com.example.data.repository.CallRepository
import com.example.data.repository.MessagingRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private const val TAG = "MainSessionVM"

class MainSessionViewModel(
    private val authProfileRepo: AuthProfileRepository,
    private val messagingRepo: MessagingRepository,
    private val callRepo: CallRepository,
    private val currentUserId: String,
) : ViewModel() {

    val myProfileState: StateFlow<UiState<PrivateUser?>> =
        authProfileRepo.observeMyProfile(currentUserId)
            .map<PrivateUser?, UiState<PrivateUser?>> { UiState.Success(it) }
            .catch { error -> emit(unwrapFlowError(error, "فشل تحميل الحساب")) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val contactsState: StateFlow<UiState<List<Contact>>> =
        messagingRepo.observeContacts(currentUserId)
            .map<List<Contact>, UiState<List<Contact>>> { UiState.Success(it) }
            .catch { error -> emit(unwrapFlowError(error, "فشل تحميل جهات الاتصال")) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    private val _peerProfiles = MutableStateFlow<Map<String, PublicProfile>>(emptyMap())
    val peerProfiles: StateFlow<Map<String, PublicProfile>> = _peerProfiles.asStateFlow()

    val conversationsState: StateFlow<UiState<List<Conversation>>> =
        messagingRepo.observeConversations(currentUserId)
            .onEach { convs -> prefetchPeerProfiles(convs) }
            .map<List<Conversation>, UiState<List<Conversation>>> { UiState.Success(it) }
            .catch { error -> emit(unwrapFlowError(error, "فشل تحميل المحادثات")) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val callsState: StateFlow<UiState<List<CallSession>>> =
        callRepo.observeMyCalls(currentUserId)
            .map<List<CallSession>, UiState<List<CallSession>>> { UiState.Success(it) }
            .catch { error -> emit(unwrapFlowError(error, "فشل تحميل المكالمات")) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val incomingCall: StateFlow<CallSession?> = callsState
        .map { state ->
            val calls = (state as? UiState.Success)?.data ?: emptyList()
            calls.firstOrNull { call ->
                call.parsedStatus == CallStatus.RINGING && call.callerId != currentUserId
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    private val _usernameAvailable = MutableStateFlow<Boolean?>(null)
    val usernameAvailable: StateFlow<Boolean?> = _usernameAvailable.asStateFlow()

    private val _searchedProfile = MutableStateFlow<PublicProfile?>(null)
    val searchedProfile: StateFlow<PublicProfile?> = _searchedProfile.asStateFlow()

    fun clearFeedback() {
        _feedbackMessage.value = null
    }

    fun checkUsername(rawUsername: String) {
        viewModelScope.launch {
            val normalized = AuthProfileRepository.normalizeUsername(rawUsername)
            if (!AuthProfileRepository.isValidUsernameFormat(normalized)) {
                _usernameAvailable.value = null
                return@launch
            }
            val result = authProfileRepo.isUsernameAvailable(normalized)
            _usernameAvailable.value = result.getOrNull()
        }
    }

    fun saveUsernameAndProfile(username: String, displayName: String, statusText: String?) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = authProfileRepo.registerUsernameAndProfile(username, displayName, statusText)
            _isBusy.value = false
            res.onFailure { _feedbackMessage.value = it.localizedMessage ?: "تعذر حفظ اسم المستخدم" }
        }
    }

    fun updateProfileInfo(displayName: String, statusText: String?) {
        val profile = (myProfileState.value as? UiState.Success)?.data ?: return
        viewModelScope.launch {
            _isBusy.value = true
            val res = authProfileRepo.updateProfileInfo(displayName, statusText, profile.username)
            _isBusy.value = false
            res.onSuccess { _feedbackMessage.value = "تم تحديث الملف الشخصي" }
            res.onFailure { _feedbackMessage.value = it.localizedMessage ?: "تعذر التحديث" }
        }
    }

    fun lookupUsername(rawUsername: String) {
        viewModelScope.launch {
            _isBusy.value = true
            _searchedProfile.value = null
            val res = authProfileRepo.lookupUserByUsername(rawUsername)
            _isBusy.value = false
            res.onSuccess { profile ->
                _searchedProfile.value = profile
                if (profile == null) {
                    _feedbackMessage.value = "لا يوجد مستخدم بهذا الاسم"
                }
            }
            res.onFailure { _feedbackMessage.value = it.localizedMessage ?: "فشل البحث" }
        }
    }

    fun clearSearchedProfile() {
        _searchedProfile.value = null
    }

    fun addContactByUsername(rawUsername: String, nickname: String?, onAdded: () -> Unit = {}) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = messagingRepo.addContactByUsername(currentUserId, rawUsername, nickname)
            _isBusy.value = false
            res.onSuccess { contact ->
                _feedbackMessage.value = "تمت إضافة ${contact.displayName} لجهات الاتصال"
                _searchedProfile.value = null
                onAdded()
            }
            res.onFailure { _feedbackMessage.value = it.localizedMessage ?: "تعذر إضافة جهة الاتصال" }
        }
    }

    fun updateContactNickname(contactUid: String, nickname: String) {
        viewModelScope.launch {
            val res = messagingRepo.updateContactNickname(currentUserId, contactUid, nickname)
            res.onSuccess { _feedbackMessage.value = "تم تحديث الاسم المستعار" }
            res.onFailure { _feedbackMessage.value = it.localizedMessage ?: "تعذر التحديث" }
        }
    }

    fun deleteContact(contactUid: String) {
        viewModelScope.launch {
            val res = messagingRepo.deleteContact(currentUserId, contactUid)
            res.onSuccess { _feedbackMessage.value = "تم حذف جهة الاتصال" }
            res.onFailure { _feedbackMessage.value = it.localizedMessage ?: "تعذر الحذف" }
        }
    }

    fun openDirectChat(targetUid: String, targetName: String, onOpened: (String) -> Unit) {
        val profile = (myProfileState.value as? UiState.Success)?.data ?: return
        viewModelScope.launch {
            _isBusy.value = true
            val res = messagingRepo.getOrCreateDirectConversation(profile, targetUid, targetName)
            _isBusy.value = false
            res.onSuccess { conv -> onOpened(conv.id) }
            res.onFailure { _feedbackMessage.value = it.localizedMessage ?: "تعذر فتح المحادثة" }
        }
    }

    fun createGroup(
        title: String,
        description: String?,
        memberUids: List<String>,
        onCreated: (String) -> Unit,
    ) {
        val profile = (myProfileState.value as? UiState.Success)?.data ?: return
        viewModelScope.launch {
            _isBusy.value = true
            val res = messagingRepo.createGroupConversation(profile, title, description, memberUids)
            _isBusy.value = false
            res.onSuccess { conv ->
                _feedbackMessage.value = "تم إنشاء المجموعة ${conv.title}"
                onCreated(conv.id)
            }
            res.onFailure { _feedbackMessage.value = it.localizedMessage ?: "تعذر إنشاء المجموعة" }
        }
    }

    fun startDirectCall(
        targetUid: String,
        targetName: String,
        mode: CallMode,
        conversationId: String? = null,
        onStarted: (String) -> Unit,
    ) {
        val profile = (myProfileState.value as? UiState.Success)?.data ?: return
        viewModelScope.launch {
            _isBusy.value = true
            val res = callRepo.startCall(
                caller = profile,
                calleeName = targetName,
                participantUids = listOf(currentUserId, targetUid),
                callMode = mode,
                conversationId = conversationId,
            )
            _isBusy.value = false
            res.onSuccess { call -> onStarted(call.id) }
            res.onFailure { _feedbackMessage.value = it.localizedMessage ?: "تعذر بدء المكالمة" }
        }
    }

    fun startGroupCall(
        conversation: Conversation,
        mode: CallMode,
        onStarted: (String) -> Unit,
    ) {
        val profile = (myProfileState.value as? UiState.Success)?.data ?: return
        viewModelScope.launch {
            _isBusy.value = true
            val res = callRepo.startCall(
                caller = profile,
                calleeName = conversation.title.ifBlank { "مكالمة جماعية" },
                participantUids = conversation.memberUids,
                callMode = mode,
                conversationId = conversation.id,
            )
            _isBusy.value = false
            res.onSuccess { call -> onStarted(call.id) }
            res.onFailure { _feedbackMessage.value = it.localizedMessage ?: "تعذر بدء مكالمة المجموعة" }
        }
    }

    fun acceptIncomingCall(callId: String, onAccepted: (String) -> Unit) {
        viewModelScope.launch {
            val res = callRepo.acceptCall(callId)
            res.onSuccess { onAccepted(callId) }
            res.onFailure { _feedbackMessage.value = it.localizedMessage ?: "تعذر الرد على المكالمة" }
        }
    }

    fun declineIncomingCall(callId: String) {
        viewModelScope.launch {
            callRepo.declineCall(callId)
        }
    }

    fun resolveDirectTitle(conversation: Conversation, contacts: List<Contact>): String {
        if (conversation.conversationType == ConversationType.GROUP) {
            return conversation.title.ifBlank { "مجموعة" }
        }
        val otherUid = conversation.memberUids.firstOrNull { it != currentUserId }
            ?: return conversation.title.ifBlank { "محادثة" }
        val contact = contacts.firstOrNull { it.contactUid == otherUid }
        if (contact != null) return contact.nickname?.takeIf { it.isNotBlank() } ?: contact.displayName
        val peer = _peerProfiles.value[otherUid]
        return peer?.displayName ?: conversation.title.ifBlank { "صديق" }
    }

    private fun prefetchPeerProfiles(conversations: List<Conversation>) {
        val unknownUids = conversations
            .flatMap { it.memberUids }
            .distinct()
            .filter { it != currentUserId && !_peerProfiles.value.containsKey(it) }
        if (unknownUids.isEmpty()) return
        viewModelScope.launch {
            val resolved = mutableMapOf<String, PublicProfile>()
            for (uid in unknownUids.take(25)) {
                authProfileRepo.getPublicProfile(uid).getOrNull()?.let { resolved[uid] = it }
            }
            if (resolved.isNotEmpty()) {
                _peerProfiles.value = _peerProfiles.value + resolved
            }
        }
    }

    private fun <T> unwrapFlowError(error: Throwable, fallback: String): UiState<T> {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, fallback, rootError)
        return UiState.Error(rootError.message ?: fallback)
    }
}
